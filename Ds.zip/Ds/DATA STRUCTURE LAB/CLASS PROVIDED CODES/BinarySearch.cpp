#include<iostream>
using namespace std;

void printArray(int A[],int n){
    for(int i=0;i<n;i++){
        cout<<A[i]<<" ";
    }
    cout<<endl;
}

int binarySearch(int A[],int n,int data){
    int low = 0;
    int high = n-1;
    while(low<=high){
        int mid = (low+high)/2;

        if(data == A[mid]){return mid;}
        else if(data < A[mid]){ high = mid-1; }
        else{ low = mid+1; }
    }
    return -1;
}

int main(){
    int A[]={2,5,8,9,13,18};

    int n = sizeof(A)/sizeof(A[0]);

    printArray(A,n);
    cout<<binarySearch(A,n,8)<<endl;
    cout<<binarySearch(A,n,18)<<endl;
    cout<<binarySearch(A,n,15)<<endl;


return 0;
}

