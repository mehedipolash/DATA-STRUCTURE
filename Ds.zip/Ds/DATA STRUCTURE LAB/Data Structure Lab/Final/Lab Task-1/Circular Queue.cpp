#include<iostream>
using namespace std;

#define size 6
int A[size];
int front = -1;
int rear = -1;

bool isEmpty()
{
    if(front == -1 && rear == -1)
    {
        return true;
    }

    else
    {
        return false;
    }
}


bool isFull()
{
    if(((rear+1)%size)==front)
    {
        return true;
    }

    else
    {
        return false;
    }
}


void enqueue(int value)
{
    if(isFull())
    {
        cout << "QUEUE IS FULL \n";
    }

    else if(isEmpty())
    {
        front = 0;
        rear = 0;
        A[rear] = value;
    }

    else
    {
        rear = (rear+1)%size;
        A[rear] = value;
    }
}


void dequeue()
{
    if(isEmpty())
    {
        cout << "QUEUE IS EMPTY \n";
    }

    else if(front == rear)
    {
        front = -1;
        rear = -1;
    }

    else
    {
       front = (front+1)%size;
    }
}


void frontValue()
{
    if(isEmpty())
    {
        cout << "QUEUE IS EMPTY \n";
    }

    else
    {
        cout << "ELEMENT AT FRONT IS : " << A[front] << endl;
    }
}


void showqueue()
{
    if(isEmpty())
    {
        cout << "QUEUE IS EMPTY \n";
    }

    else
    {
        int i;
        if(front<=rear)
        {
            for(int i = front; i <= rear; i++)
           {
            cout << A[i] << " ";
           }
        cout << endl;

        }

        else
        {
            int i=front;
            while(i<size)
            {
               cout << A[i] << " ";
               i++;
            }
            i=0;
            while(i<=rear)
            {
                cout << A[i] << " ";
                i++;
            }

        }

    }
}


int main()
{
    enqueue(1);
    enqueue(4);
    enqueue(7);
    showqueue();
    dequeue();
    enqueue(3);
    enqueue(5);
    showqueue();
    dequeue();
    dequeue();
    dequeue();
    enqueue(2);
    enqueue(9);
    showqueue();
    return 0;
}
