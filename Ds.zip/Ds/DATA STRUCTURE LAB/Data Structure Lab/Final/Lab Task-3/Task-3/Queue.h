#include <iostream>
#include "LinkedList.h"

namespace queueList
{
    // Assuming LinkedList implementation is defined here
}

template<typename DType>
class Queue
{
private:
    queueList::LinkedList<DType> myQueueList;
public:
    Queue()
    {
    }

    void enqueue(DType data)
    {
        myQueueList.insertBack(data);
    }

    void dequeue()
    {
        if (!myQueueList.isEmpty())
        {
            myQueueList.removeFront();
        }
        else
        {
            std::cerr << "Queue is empty. Cannot dequeue." << std::endl;
        }
    }

    DType front()
    {
        if (!myQueueList.isEmpty())
        {
            return myQueueList.front();
        }
        else
        {
            std::cerr << "Queue is empty. Cannot return front." << std::endl;
            return DType();
        }
    }

    void display()
    {
        if (!myQueueList.isEmpty())
        {
            std::cout << "Queue elements: ";
            myQueueList.display();
        }
        else
        {
            std::cout << "Queue is empty." << std::endl;
        }
    }
};

int main()
{
    Queue<int> myQueue;

    myQueue.enqueue(10);
    myQueue.enqueue(20);
    myQueue.enqueue(30);
    myQueue.enqueue(40);

    myQueue.display();  // Queue elements: 10 20 30 40

    std::cout << "Front element: " << myQueue.front() << std::endl;  // Front element: 10

    myQueue.dequeue();
    myQueue.dequeue();

    myQueue.display();  // Queue elements: 30 40

    return 0;
}
