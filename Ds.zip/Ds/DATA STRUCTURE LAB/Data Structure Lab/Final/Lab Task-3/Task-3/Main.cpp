#include<iostream>
#include "LinkedList.h"
#include "Stack.h"
#include "Queue.h"
using namespace std;

int main()
{

    // Create a linked list of integers
    LinkedList<int> myLinkedList;
    myLinkedList.insertAtFirst(20);
    myLinkedList.insertAtLast(10);
    myLinkedList.insertAtLast(30);
    cout << "Output of LinkedList" << endl;
    myLinkedList.display();

    // Create a stack of integers
    Stack<int> myIntStack;
    myIntStack.push(10);
    myIntStack.push(20);
    myIntStack.push(30);
    cout << "Output of Integer Stack" << endl;
    myIntStack.display();

    // Create a stack of strings
    Stack<string> myStringStack;
    myStringStack.push("One");
    myStringStack.push("Two");
    myStringStack.push("Three");
    myStringStack.push("Four");
    cout << "Output of String Stack" << endl;
    myStringStack.display();

    // Create a queue of integers
    Queue<int> myIntQueue;
    myIntQueue.enqueue(10);
    myIntQueue.enqueue(20);
    myIntQueue.enqueue(30);
    cout << "Output of Integer Queue" << endl;
    myIntQueue.display();

    // Create a queue of strings
    Queue<string> myStringQueue;
    myStringQueue.enqueue("One");
    myStringQueue.enqueue("Two");
    myStringQueue.enqueue("Three");
    myStringQueue.enqueue("Four");
    cout << "Output of String Queue" << endl;
    myStringQueue.display();

    return 0;
}
