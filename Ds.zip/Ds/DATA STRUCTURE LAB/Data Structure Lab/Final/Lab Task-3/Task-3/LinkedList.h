#include<iostream>

template<typename DType>
class LinkedList
{
private:
    class Node
    {
    public:
        DType data;
        Node* next;

        Node()
        {
        }
        Node(DType data)
        {
            this->data = data;
            this->next = NULL;
        }
    };

    Node* head = NULL;
    Node* curr = NULL;

    Node* createNode(DType data)
    {
        return new Node(data);
    }

public:
    void insertAtFirst(DType data)
    {

        Node* newNode = createNode(data);

        if(head == NULL)
        {
            head = newNode;
            curr = newNode;
        }
        else
        {
            newNode->next = head;
            head = newNode;
        }
    }

    void insertAtLast(DType data)
    {
        if(head == NULL)
        {
            insertAtFirst(data);
        }
        else
        {
            curr->next = createNode(data);
            curr = curr->next;
        }
    }

    void deleteAtLast()
    {
        if (head == NULL)
        {
            std::cerr << "Cannot delete from an empty list." << std::endl;
            return;
        }
        if (head == curr)
        {
            delete head;
            head = NULL;
            curr = NULL;
            return;
        }
        Node* temp = head;
        while (temp->next != curr)
        {
            temp = temp->next;
        }
        delete curr;
        curr = temp;
        curr->next = NULL;
    }

    void deleteAtFirst()
    {
        if (head == NULL)
        {
            std::cerr << "Cannot delete from an empty list." << std::endl;
            return;
        }
        if (head == curr)
        {
            delete head;
            head = NULL;
            curr = NULL;
            return;
        }
        Node* temp = head;
        head = head->next;
        delete temp;
    }

    DType getLastElement()
    {
        if (head == NULL)
        {
            std::cerr << "Cannot get last element from an empty list." << std::endl;
            return DType();
        }
        return curr->data;
    }

    DType getFirstElement()
    {
        if (head == NULL)
        {
            std::cerr << "Cannot get first element from an empty list." << std::endl;
            return DType();
        }
        return head->data;
    }

    void display()
    {
        Node* temp = head;
        while( temp !=NULL)
        {
            std::cout<<temp->data<<std::endl;
            temp = temp->next;
        }
    }

};
