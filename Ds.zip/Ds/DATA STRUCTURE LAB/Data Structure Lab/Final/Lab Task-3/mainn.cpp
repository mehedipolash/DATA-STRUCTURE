
#include<iostream>
#include "LinkedList.h"
#include "Stack.h"
#include "Queue.h"

using namespace std;

int main(){

    LinkedList<int> myLinkedList;
    myLinkedList.insertAtFirst(20);
    myLinkedList.insertAtLast(10);
    myLinkedList.insertAtLast(30);
    cout<<"Output of LinkedList"<<endl;
    myLinkedList.display();

    Stack<int> myStack;
    myStack.push(10);
    myStack.push(20);
    myStack.push(30);

    cout<<"Output of Stack"<<endl;
    myStack.display();

    Stack<string> myStringStack;
    myStringStack.push("One");
    myStringStack.push("Two");
    myStringStack.push("Three");
    myStringStack.push("Four");
    cout<<"Output of Stack"<<endl;
    myStringStack.display();

    Queue<int> myQueue;
    myQueue.enqueue(10);
    myQueue.enqueue(20);
    myQueue.enqueue(30);

    cout<<"Output of Queue"<<endl;
    myQueue.display();
    myQueue.dequeue();
    cout<<"After dequeue operation"<<endl;
    myQueue.display();
    cout<<"Front element of the queue is: "<<myQueue.front()<<endl;

    return 0;
}
