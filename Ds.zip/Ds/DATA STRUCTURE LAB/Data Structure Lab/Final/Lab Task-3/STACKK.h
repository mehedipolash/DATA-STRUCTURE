#include "LinkedList.h"

namespace stackList {
    template<typename DType>
    class Stack {
    private:
        LinkedList<DType> myStackList;
    public:
        Stack() {}

        void push(DType data) {
            myStackList.insertAtLast(data);
        }

        void pop() {
            myStackList.deleteAtLast();
        }

        DType top() {
            return myStackList.getLastElement();
        }

        void display() {
            myStackList.display();
        }
    };
}

template<typename DType>
using Stack = stackList::Stack<DType>;

