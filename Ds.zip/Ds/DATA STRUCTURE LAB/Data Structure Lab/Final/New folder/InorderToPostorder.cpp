#include <iostream>

using namespace std;

struct Node {
    int value;
    Node* left;
    Node* right;
    Node(int val) {
        value = val;
        left = NULL;
        right = NULL;
    }
};

void inorderToPostorderTraversal(Node* node) {
    if (node == NULL) {
        return;
    }
    inorderToPostorderTraversal(node->left);
    inorderToPostorderTraversal(node->right);
    cout << node->value << " ";
}

int main() {
    Node* root = new Node(1);
    root->left = new Node(2);
    root->right = new Node(3);
    root->left->left = new Node(4);
    root->left->right = new Node(5);
    cout << "Inorder to Postorder Traversal: ";
    inorderToPostorderTraversal(root);
    cout << endl;
    return 0;
}
