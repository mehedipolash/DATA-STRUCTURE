#include <iostream>
using namespace std;

// Node class
class Node {
public:
    int data;
    Node* next;
    Node* prev;
};

// Doubly linked list class
class DoublyLinkedList {
private:
    Node* head;
public:
    DoublyLinkedList() {
        head = NULL;
    }

    // Add a node to the end of the list
    void append(int data) {
        Node* new_node = new Node();
        new_node->data = data;
        new_node->next = NULL;

        if (head == NULL) {
            new_node->prev = NULL;
            head = new_node;
            return;
        }

        Node* current = head;
        while (current->next != NULL) {
            current = current->next;
        }

        current->next = new_node;
        new_node->prev = current;
    }

    // Print the list from the head to the tail
    void print_forward() {
        Node* current = head;
        while (current != NULL) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }

    // Print the list from the tail to the head
    void print_backward() {
        Node* current = head;
        while (current->next != NULL) {
            current = current->next;
        }

        while (current != NULL) {
            cout << current->data << " ";
            current = current->prev;
        }
        cout << endl;
    }
};

// Main function to test the implementation
int main() {
    DoublyLinkedList list;

    list.append(1);
    list.append(2);
    list.append(3);

    cout << "Forward: ";
    list.print_forward();

    cout << "Backward: ";
    list.print_backward();

    return 0;
}
