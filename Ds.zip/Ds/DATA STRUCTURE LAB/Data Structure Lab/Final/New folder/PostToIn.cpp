#include <iostream>
#include <stack>

using namespace std;

struct Node {
    int value;
    Node* left;
    Node* right;
    Node(int val) {
        value = val;
        left = NULL;
        right = NULL;
    }
};

void postorderToInorderTraversal(int arr[], int n) {
    stack<Node*> s;
    Node* root = new Node(arr[n-1]);
    s.push(root);
    Node* temp = NULL;
    for (int i = n-2; i >= 0; i--) {
        while (!s.empty() && arr[i] < s.top()->value) {
            temp = s.top();
            s.pop();
        }
        if (temp != NULL) {
            temp->left = new Node(arr[i]);
            s.push(temp->left);
            temp = NULL;
        } else {
            s.top()->right = new Node(arr[i]);
            s.push(s.top()->right);
        }
    }
    while (!s.empty()) {
        cout << s.top()->value << " ";
        s.pop();
    }
}

int main() {
    int arr[] = {4, 5, 2, 3, 1};
    int n = sizeof(arr)/sizeof(arr[0]);
    cout << "Postorder to Inorder Traversal: ";
    postorderToInorderTraversal(arr, n);
    cout << endl;
    return 0;
}
