#include <iostream>
#include <stack>

using namespace std;

struct Node {
    int value;
    Node* left;
    Node* right;
    Node(int val) {
        value = val;
        left = NULL;
        right = NULL;
    }
};

void postorderToPreorderTraversal(int arr[], int n) {
    stack<Node*> s;
    Node* root = new Node(arr[n-1]);
    s.push(root);
    for (int i = n-2; i >= 0; i--) {
        Node* temp = new Node(arr[i]);
        if (arr[i] > s.top()->value) {
            while (!s.empty() && arr[i] > s.top()->value) {
                temp->left = s.top();
                s.pop();
            }
        }
        if (!s.empty()) {
            s.top()->right = temp;
        }
        s.push(temp);
    }
    cout << "Postorder to Preorder Traversal: ";
    while (!s.empty()) {
        cout << s.top()->value << " ";
        s.pop();
    }
}

int main() {
    int arr[] = {4, 5, 2, 3, 1};
    int n = sizeof(arr)/sizeof(arr[0]);
    postorderToPreorderTraversal(arr, n);
    cout << endl;
    return 0;
}
