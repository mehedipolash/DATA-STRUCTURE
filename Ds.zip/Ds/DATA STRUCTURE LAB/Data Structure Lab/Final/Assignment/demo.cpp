#include <iostream>
using namespace std;

class SingleLinkedList

{
// Single Linked List
    int data;
    SingleLinkedList *next; // Pointer to next node
public:
    void insertAtLast(int d)
    {                                                     // Insert at last
        SingleLinkedList *temp = new SingleLinkedList(d); // Create a new node
        if (next == NULL)
        {
            next = temp; // If list is empty, insert at first
        }
        else
        {
            SingleLinkedList *t = next;
            while (t->next != NULL)
            { // Traverse till last node
                t = t->next;
            }
            t->next = temp;
        }
    }

    void insertAtFirst(int d)
    { // Insert at first
        SingleLinkedList *temp = new SingleLinkedList(d);
        if (next == NULL)
        { // If list is empty, insert at first
            next = temp;
        }
        else
        { // Else, insert at first
            temp->next = next;
            next = temp;
        }
    }

    void insertAtAnyPos(int d, int pos)
    { // Insert at any position
        SingleLinkedList *temp = new SingleLinkedList(d);
        if (next == NULL)
        { // If list is empty, insert at first
            next = temp;
        }
        else
        { // Else, insert at any position
            SingleLinkedList *t = next;
            SingleLinkedList *prev = NULL;
            int i = 1;
            while (t != NULL)
            { // Traverse till position
                if (i == pos)
                { // Insert at position
                    if (prev == NULL)
                    {                      // If position is first
                        temp->next = next; // Insert at first
                        next = temp;       // Update head
                        break;             // Break loop
                    }
                    else
                    {
                        prev->next = temp; // Insert at any position
                        temp->next = t;    // Update next pointer
                        break;
                    }
                }
                prev = t;    // Update previous pointer
                t = t->next; // Update current pointer
                i++;
            }
        }
    }

    void insertBeforeElement(int d, int e)
    { // Insert before element
        SingleLinkedList *temp = new SingleLinkedList(d); // Create a new node
        if (next == NULL)
        {                // If list is empty, insert at first
            next = temp; // Insert at first
        }
        else
        {
            SingleLinkedList *t = next;    // Traverse till element
            SingleLinkedList *prev = NULL; // Previous pointer
            while (t != NULL)
            { // Traverse till element
                if (t->data == e)
                { // Insert before element
                    if (prev == NULL)
                    {                      // If element is first
                        temp->next = next; // Insert at first
                        next = temp;       // Update head
                        break;
                    }
                    else
                    {
                        prev->next = temp; // Insert before element
                        temp->next = t;    // Update next pointer
                        break;
                    }
                }
                prev = t;    // Update previous pointer
                t = t->next; // Update current pointer
            }
        }
    }

    void displayList()
    { // Display list
        SingleLinkedList *t = next;
        while (t != NULL)
        { // Traverse till last
            cout << t->data << " "
                 << "SingleList" << endl; // Display data
            t = t->next;                  // Update current pointer
        }
    }

    void deleteElementByValue(int d)
    { // Delete element by value
        SingleLinkedList *t = next;
        SingleLinkedList *prev = NULL;
        while (t != NULL)
        { // Traverse till element
            if (t->data == d)
            { // Searching element
                if (prev == NULL)
                {
                    next = t->next;
                    delete t; // Delete element
                    break;    // Break loop
                }
                else
                { // Delete element
                    prev->next = t->next;
                    delete t;
                    break;
                }
            }
            prev = t;    // Update previous pointer
            t = t->next; // Update current pointer
        }
    }

    void deleteAtPos(int pos)
    { // Delete at position
        SingleLinkedList *t = next;
        SingleLinkedList *prev = NULL;
        int i = 1;
        while (t != NULL)
        {
            if (i == pos)
            { // Searching position
                if (prev == NULL)
                {                   // If position is first
                    next = t->next; // Update head
                    delete t;       // Delete element
                    break;
                }
                else
                { // Delete element
                    prev->next = t->next;
                    delete t;
                    break;
                }
            }
            prev = t;    // Update previous pointer
            t = t->next; // Update current pointer
            i++;         // Update position
        }
    }

    void displayList()
{
    ListNode* curr = head;
    while (curr != nullptr)
    {
        cout << curr->val << " ";
        curr = curr->next;
    }
    cout << endl;
}

};



class DoubleLinkedList
{                           // Double Linked List
    int data;               // Data
    DoubleLinkedList *next; // Pointer to next node
    DoubleLinkedList *prev; // Pointer to previous node
public:
    void insertAtLast(int d)
    {                                                     // Insert at last
        DoubleLinkedList *temp = new DoubleLinkedList(d); // Create a new temporary node
        if (next == NULL)
        {                      // If list is empty, insert at first
            next = temp;       // Insert at first
            temp->prev = this; // Update previous pointer
        }
        else
        { // Else, insert at last
            DoubleLinkedList *t = next;
            while (t->next != NULL)
            {                // Traverse till last
                t = t->next; // Update current pointer
            }
            t->next = temp; // Insert at last
            temp->prev = t; // Update previous pointer
        }
    }

    void insertAtFirst(int d)
    {                                                     // Insert at first
        DoubleLinkedList *temp = new DoubleLinkedList(d); // Create a new temporary node
        if (next == NULL)
        {                      // If list is empty, insert at first
            next = temp;       // Insert at first
            temp->prev = this; // Update previous pointer
        }
        else
        {                      // Else, insert at first and upadate the list
            temp->next = next; // Insert at first
            next->prev = temp; // Update previous pointer
            next = temp;       // Update head
            temp->prev = this; // Update previous pointer
        }
    }

    void insertAtAnyPos(int d, int pos)
    {                                                     // Insert at any position
        DoubleLinkedList *temp = new DoubleLinkedList(d); // Create a new temporary node
        if (next == NULL)
        {                      // If list is empty, insert at first
            next = temp;       // Insert at first
            temp->prev = this; // Update previous pointer
        }
        else
        {                                  // Else, insert at given position
            DoubleLinkedList *t = next;    // Traverse till position
            DoubleLinkedList *prev = NULL; // Previous pointer
            int i = 1;                     // Position
            while (t != NULL)
            { // Traverse till position
                if (i == pos)
                { // Insert at position
                    if (prev == NULL)
                    {                      // If position is first
                        temp->next = next; // Insert at first
                        next->prev = temp; // Update previous pointer
                        next = temp;       // Update head
                        temp->prev = this; // Update previous pointer
                        break;             // Break loop
                    }
                    else
                    {                      // Insert at given position
                        prev->next = temp; // Insert at any position
                        temp->prev = prev; // Update previous pointer
                        temp->next = t;    // Update next pointer
                        t->prev = temp;    // Update previous pointer
                        break;             // Break loop
                    }
                }
                prev = t;    // Update previous pointer
                t = t->next; // Update current pointer
                i++;
            }
        }
    }

    void insertBeforeElement(int d, int e)
    {                                                     // Insert before element
        DoubleLinkedList *temp = new DoubleLinkedList(d); // Create a new temporary node
        if (next == NULL)
        {                      // If list is empty, insert at first
            next = temp;       // Insert at first
            temp->prev = this; // Update previous pointer
        }
        else
        {                                  // Else, insert before element
            DoubleLinkedList *t = next;    // Traverse till element
            DoubleLinkedList *prev = NULL; // Previous pointer
            while (t != NULL)
            { // Traverse till element
                if (t->data == e)
                { // Insert before element
                    if (prev == NULL)
                    {                      // If element is first
                        temp->next = next; // Inserting
                        next->prev = temp; // Update previous pointer
                        next = temp;       // Update head
                        temp->prev = this; // Update previous pointer
                        break;
                    }
                    else
                    {                      // Insert before element
                        prev->next = temp; // Inserting
                        temp->prev = prev; // Update previous pointer
                        temp->next = t;    // Update next pointer
                        t->prev = temp;    // Update previous pointer
                        break;
                    }
                }
                prev = t;    // Update previous pointer
                t = t->next; // Update current pointer
            }
        }
    }

    void displayList()
    { // Display list
        DoubleLinkedList *t = next;
        while (t != NULL)
        { // Traverse till last
            cout << t->data << " "
                 << "Double List" << endl; // Display data
            t = t->next;                   // Update current pointer
        }
    }

    void deleteElementByValue(int d)
    { // Delete element by value
        DoubleLinkedList *t = next;
        DoubleLinkedList *prev = NULL; // Previous pointer
        while (t != NULL)
        { // Traverse till element
            if (t->data == d)
            { // Delete element checking value
                if (prev == NULL)
                {                      // If element is first
                    next = t->next;    // Update head
                    next->prev = this; // Update previous pointer
                    delete t;          // Delete element
                    break;
                }
                else
                {                         // Delete element
                    prev->next = t->next; // Update next pointer
                    t->next->prev = prev; // Update previous pointer
                    delete t;             // Delete element
                    break;
                }
            }
            prev = t;    // Update previous pointer
            t = t->next; // Update current pointer
        }
    }

    void deleteAtPos(int pos)
    {                                  // Delete element at position
        DoubleLinkedList *t = next;    // Traverse till position
        DoubleLinkedList *prev = NULL; // Previous pointer
        int i = 1;                     // Position
        while (t != NULL)
        { // Traverse till position
            if (i == pos)
            { // Delete element at position
                if (prev == NULL)
                {                      // If position is first
                    next = t->next;    // Update head
                    next->prev = this; // Update previous pointer
                    delete t;          // Delete element
                    break;
                }
                else
                {                         // Delete element at position
                    prev->next = t->next; // Update next pointer
                    t->next->prev = prev; // Update previous pointer
                    delete t;             // Delete element
                    break;
                }
            }
            prev = t;    // Update previous pointer
            t = t->next; // Update current pointer
            i++;         // Update position
        }
    }

    void displayList()
{
    ListNode* curr = head;
    while (curr != nullptr)
    {
        cout << curr->val << " ";
        curr = curr->next;
    }
    cout << endl;
}


};


// Node class for the linked list
class Node
{
public:
    int data;
    Node* next;

    Node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }
};

// Stack class using linked list
class Stack
{
private:
    Node* topNode;
public:
    Stack()
    {
        topNode = nullptr;
    }

    void push(int data)
    {
        Node* newNode = new Node(data);
        newNode->next = topNode;
        topNode = newNode;
    }

    int pop()
    {
        if (topNode == nullptr)
        {
            cout << "Stack is empty!" << endl;
            return -1;
        }
        int data = topNode->data;
        Node* temp = topNode;
        topNode = topNode->next;
        delete temp;
        return data;
    }

    int top()
    {
        if (topNode == nullptr)
        {
            cout << "Stack is empty!" << endl;
            return -1;
        }
        return topNode->data;
    }
};

// Queue class using linked list
class Queue
{
private:
    Node* frontNode;
    Node* rearNode;
public:
    Queue()
    {
        frontNode = nullptr;
        rearNode = nullptr;
    }

    void enqueue(int data)
    {
        Node* newNode = new Node(data);
        if (rearNode == nullptr)
        {
            frontNode = newNode;
            rearNode = newNode;
        }
        else
        {
            rearNode->next = newNode;
            rearNode = newNode;
        }
    }

    int dequeue()
    {
        if (frontNode == nullptr)
        {
            cout << "Queue is empty!" << endl;
            return -1;
        }
        int data = frontNode->data;
        Node* temp = frontNode;
        frontNode = frontNode->next;
        if (frontNode == nullptr)
        {
            rearNode = nullptr;
        }
        delete temp;
        return data;
    }

    int front()
    {
        if (frontNode == nullptr)
        {
            cout << "Queue is empty!" << endl;
            return -1;
        }
        return frontNode->data;
    }

    int rear()
    {
        if (rearNode == nullptr)
        {
            cout << "Queue is empty!" << endl;
            return -1;
        }
        return rearNode->data;
    }
};



class TreeNode
{
public:
    int val;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : val(val), left(nullptr), right(nullptr) {}
};

class BST
{
private:
    TreeNode* root;

public:
    BST() : root(nullptr) {}

    void insertIntoBST(int val)
    {
        TreeNode* node = new TreeNode(val);
        if (root == nullptr)
        {
            root = node;
            return;
        }

        TreeNode* curr = root;
        while (true)
        {
            if (val < curr->val)
            {
                if (curr->left == nullptr)
                {
                    curr->left = node;
                    break;
                }
                curr = curr->left;
            }
        else
            {
                if (curr->right == nullptr)
                {
                    curr->right = node;
                    break;
                }
                curr = curr->right;
            }
        }
    }

    TreeNode* searchInBST(int val)
    {
        TreeNode* curr = root;
        while (curr != nullptr)
            {
            if (curr->val == val)
            {
                return curr;
            }
        else if (val < curr->val)
            {
                curr = curr->left;
            }

        else
            {
                curr = curr->right;
            }
        }
        return nullptr;
    }

    void displayInorder(TreeNode* node)
    {
        if (node == nullptr)
        {
            return;
        }
        displayInorder(node->left);
        cout << node->val << " ";
        displayInorder(node->right);
    }

    void displayInorder()
    {
        displayInorder(root);
        cout << endl;
    }

    void displayPreorder(TreeNode* node)
    {
        if (node == nullptr)
        {
            return;
        }
        cout << node->val << " ";
        displayPreorder(node->left);
        displayPreorder(node->right);
    }

    void displayPreorder()
    {
        displayPreorder(root);
        cout << endl;
    }

    void displayPostorder(TreeNode* node)
    {
        if (node == nullptr)
        {
            return;
        }
        displayPostorder(node->left);
        displayPostorder(node->right);
        cout << node->val << " ";
    }

    void displayPostorder()
    {
        displayPostorder(root);
        cout << endl;
    }
};

int main()
{
    BST tree;
    tree.insertIntoBST(5);
    tree.insertIntoBST(3);
    tree.insertIntoBST(7);
    tree.insertIntoBST(1);
    tree.insertIntoBST(9);

    TreeNode* found = tree.searchInBST(3);
    if (found != nullptr)
    {
        cout << "Found value: " << found->val << endl;
    }

    else
    {
        cout << "Value not found" << endl;
    }

    cout << "In-order traversal: ";
    tree.displayInorder();

    cout << "Pre-order traversal: ";
    tree.displayPreorder();

    cout << "Post-order traversal: ";
    tree.displayPostorder();

    return 0;
}

