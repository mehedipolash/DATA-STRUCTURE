#include <iostream>
using namespace std;

int main()

{
    int size, flag=0;
    cout<<"Enter size of the array: ";
    cin>>size;


    int Array[size];
    cout<<"\nPut the elements of the array: ";
    for(int i=0; i<size; i++)

    {
        cin >> Array[i];
    }


    for (int i = 0; i < size; i++)

    {
        int j;
        for(j = 0; j < i; j++)

        {
            if (Array[i] == Array[j])

            {
                flag = 1;
                break;
            }

        }
        cout<<endl;
        if (i == j)

        {
            cout << Array[i] << " ";
        }
    }
      cout<<endl;
    if(flag == 0)

    {
        cout<<"Array already unique! ";
    }

    cout << endl << endl;

    return 0;

}
