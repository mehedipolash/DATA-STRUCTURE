#include <iostream>
using namespace std;

int main()

{
    int a, b;
    cout<<"Enter size of the 1st array: ";
    cin>>a;
    cout<<"Enter size of the 2nd array: ";
    cin>>b;

    int Array1[a], Array2[b], Array3[a+b];

    cout<<"\nPut element of the 1st array: ";


    for(int i=0; i<a; i++)

    {
        cin >> Array1[i];
    }


    cout<<"\nPut element of the 2nd array: ";


    for(int i=0; i<b; i++)


        cin >> Array2[i];
    }

    int j = 0;
    for(int i = 0 ; i < a+b; i++)

    {
        if(i < a)

        {
            Array3[i] = Array1[i];
        }

        else
        {
            Array3[i] = Array2[j];
            j++;
        }
    }

    cout << "\nAfter merging: ";


    for (int i = 0; i < a+b; i++)

    {
        cout << Array3[i] <<" ";
    }

    cout << "\nIn reverse order: ";


    for (int i = a+b-1; i >= 0; i--)

    {
        cout << Array3[i] <<" ";
    }

    cout<<endl<<endl;

    return 0;
}
