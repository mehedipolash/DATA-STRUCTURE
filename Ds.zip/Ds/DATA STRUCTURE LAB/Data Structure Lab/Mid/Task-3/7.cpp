#include <iostream>
using namespace std;
struct Student

{

    int id;
    string name;
    double cgpa;
    char gender;
    int creditCompleted;
    string depertment;
    bool checkProbation(double cgpa)

    {

        if(cgpa<2.5)

        {
            return true;
        }

        else

        {
            return false;
        }
    }

};

int main()

{

    Student s[5];
    for(int i=0; i<5; i++)

    {

        cout<<"Entered "<<i+1<<" Student Details : "<<endl;
        cout<<"Id                 : ";
        cin>>s[i].id;
        cout<<"Name               : ";
        getline(cin,s[i].name);
        getline(cin,s[i].name);
        cout<<"Cgpa               : ";
        cin>>s[i].cgpa;
        cout<<"Gender             : ";
        cin>>s[i].gender;
        cout<<"CreditCompleted    : ";
        cin>>s[i].creditCompleted;
        cout<<"Depertment         : ";
        cin>>s[i].depertment;

    }

    for(int i=0; i<5; i++)

    {

        cout<<"Student "<<i+1<<" Details : "<<endl;
        cout<<"ID               : "<<s[i].id<<endl;
        cout<<"Name             : "<<s[i].name<<endl;
        cout<<"Cgpa             : "<<s[i].cgpa<<endl;
        cout<<"Gender           : "<<s[i].gender<<endl;
        cout<<"CreditCompleted  : "<<s[i].creditCompleted<<endl;
        cout<<"Depertment       : "<<s[i].depertment<<endl;
        cout<<"Probation status : ";

        if(s[i].checkProbation(s[i].cgpa))

        {
            cout<<"Yes"<<endl;
        }

        else

        {
            cout<<"No"<<endl;
        }

    }

 }
