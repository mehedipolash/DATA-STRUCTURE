#include <iostream>
using namespace std;
int main()

{

    string m;
    cout<<"ENTER YOUR STRING HERE\n"<<endl;
    getline(cin,m);


    int count=0;

    for(int i=0;i<m.length();i++)

    {

        char n=tolower(m[i]);
        if(n=='a'||n=='e'||n=='i'||n=='o'||n=='u')

        {
            count++;
        }

    }

              cout<<"vowels appeared "<<count<< " times."<<endl;

}
