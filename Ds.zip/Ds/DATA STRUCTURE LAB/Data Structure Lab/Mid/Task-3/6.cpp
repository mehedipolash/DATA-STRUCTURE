#include <iostream>
using namespace std;
void encode(string s,int j)

{

    for(int i=j;i<s.length();i+=j+1)

    {
        s[i]=s[i]+j;
    }

    cout<<"\nConverted String : "<<s<<endl;

}

int main()

{

    string s;
    cout<<"\nSample String (s): ";
    getline(cin,s);

    int j;
    cout<<"\nSample Integer (j): ";
    cin>>j;
    encode(s,j);

 }
