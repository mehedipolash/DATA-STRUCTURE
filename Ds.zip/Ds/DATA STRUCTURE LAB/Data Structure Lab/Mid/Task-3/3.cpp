#include <iostream>
using namespace std;
int main()

{

    string v,n;

    cout<<"ENTER YOUR 1st STRING HERE\n"<<endl;
    getline(cin,v);


    cout<<"\nENTER YOUR 2nd STRING HERE\n"<<endl;
    getline(cin,n);


    string Z = v+n;
    cout<<Z<<endl;


}
