#include <iostream>
using namespace std;
int main()

{
    string v;
    cout<<"ENTER YOUR STRING HERE\n"<<endl;
    //getline(cin,v);
    cin>>v;


    cout<<"\nLength of string is "<<v.length()<<endl;

}
