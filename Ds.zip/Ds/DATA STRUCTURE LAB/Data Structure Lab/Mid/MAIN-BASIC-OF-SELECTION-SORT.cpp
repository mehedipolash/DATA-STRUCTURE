
#include<iostream>
using namespace std;

 void printArray(int arr[],int size)
 {
    for(int i=0;i<size;i++)
        {
        cout<<arr[i]<<" ";
        }
        cout<<endl;
 }

void selectionsort(int arr[],int size)
{
    for(int i=0; i<size-1;i++)

    {
        int minimumindex = i;

        for(int j=i+1; j<size; j++)
        {
            if(arr [minimumindex]>arr[j])
            {
                minimumindex=j;
            }
        }
        int temp= arr[i];
        arr[i]=arr[minimumindex];
        arr[minimumindex]=temp;


    }
}





int main()
{
    int size = 15;
    int data[] = {35,14,7,9,46,26,17,49,6,9,33,4,17,37,22};

    cout<<"Unsorted Data"<<endl;
    printArray(data,15);


    selectionsort(data,15);


    cout<<"Sorted Data"<<endl;
    printArray(data,15);

return 0;
}
