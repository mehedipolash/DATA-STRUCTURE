#include<iostream>
using namespace std;
int main()
{
    int arr[10]={12,32,43,1,54,53,15,64,3,13};
    int i=0;
    int even=0;
    int odd=0;
     for( int i=0; i<=10 ; i++)
    {
         if(arr[i]%2==0)

            {
                even++;
            }
        else
            {
                odd++;
            }
    }
    cout<<"The even Number is : "<<even<<" "<<endl;
    cout<<"The Odd number     : "<<odd<<" " ;
    return 0;
}
