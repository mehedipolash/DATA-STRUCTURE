
#include<iostream>
#include<stdlib.h>
using namespace std;

void print(int arr[], int s)
{
    cout<<"\nArray = [";
    for(int i=0; i <s-1; i++)
        cout<<arr[i]<<",";

    if(s <= 0)
        cout<<" ]\n";
    else
        cout<<arr[s-1]<<"]\n";
}

void selectionSort(int array[], int size) {
  for (int step = 0; step < size - 1; step++) {
    int min_idx = step;
    for (int i = step + 1; i < size; i++) {

      // To sort in descending order, change > to < in this line.
      // Select the minimum element in each loop.
      if (array[i] < array[min_idx])
        min_idx = i;
    }

    // put min at the correct position
    swap(array[min_idx],array[step]);
  }
}

int main()
{
    int ne;
    cout<< "\nHow many elements? ";
    cin>>ne;

    //Auto input
    int myArray[ne];
    myArray[0] = rand()%10;
    for(int i=1; i<ne; i++)
    {
        myArray[i] = myArray[i-1] + rand()%10;
    }
    selectionSort(myArray, ne);
    cout << "Sorted array in Acsending Order:\n";

    print(myArray,ne);

    main();
}

