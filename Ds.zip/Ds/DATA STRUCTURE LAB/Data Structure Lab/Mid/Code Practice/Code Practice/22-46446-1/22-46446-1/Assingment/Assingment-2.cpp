#include <iostream>
using namespace std;

struct BstNode
{
    string iD;
    string name;
    float cgpa;
    BstNode *left;
    BstNode *right;
};
BstNode *root;
BstNode *GetNewNode(string iD0, string n0, float cg0)
{
    BstNode *NewNode = new BstNode();
    NewNode->iD = iD0;
    NewNode->name = n0;
    NewNode->cgpa = cg0;
    NewNode->left = NULL;
    NewNode->right = NULL;
    return NewNode;
}

void PreOrder(BstNode *root)
{
    if (root == NULL)
    {
        return;
    }
    cout << "ID: " << root->iD << "\nNAME: " << root->name << "\nCGPA: " << root->cgpa << endl;
    PreOrder(root->left);
    PreOrder(root->right);
}
void InOrder(BstNode *root)
{
    if (root == NULL)
    {
        return;
    }
    InOrder(root->left);
    cout << "ID: " << root->iD << "\nNAME: " << root->name << "\nCGPA: " << root->cgpa << endl;
    InOrder(root->right);
}
void PostOrder(BstNode *root)
{
    if (root == NULL)
    {
        return;
    }
    PostOrder(root->left);
    PostOrder(root->right);
    cout << "ID: " << root->iD << "\nNAME: " << root->name << "\nCGPA: " << root->cgpa << endl;
    cout << endl;
}
BstNode *Insert(BstNode *root, string iD2, string n2, float cg2)
{
    if (root == NULL)
    {
        root = GetNewNode(iD2, n2, cg2);
    }
    else if (iD2 <= root->iD)
    {
        root->left = Insert(root->left, iD2, n2, cg2);
    }
    else
    {
        root->right = Insert(root->right, iD2, n2, cg2);
    }
    return root;
}


    BstNode *Search(BstNode * root, string iDs)
    {
        cout << "Finding " << endl;
        if (root == NULL)
        {
            cout << "No result!" << endl;
            return root;
        }
        else if (root->iD == iDs)
        {
            cout << "ID: " << root->iD << endl;
            cout << "NAME: " << root->name << endl;
            cout << "CGPA: " << root->cgpa << endl;
            bool done = false;


            return root;
        }
    }
        /*if (iDs <= root->iD)
        {
            return Search(root->left, iDs);
        }
        else
        {
            return Search(root->right, iDs);
        }*/


    int main()
    {
        root = NULL;
        root = Insert(root, "21-44631-1", "Rafiul", 3.75);
        root = Insert(root, "21-44531-1", "Haque", 4.0);
        root = Insert(root, "21-44431-1", "Rafsun", 3.78);
        root = Insert(root, "21-44331-1", "Rafi", 3.5);
        root = Insert(root, "21-44231-1", "ABC", 4.0);
        root = Insert(root, "21-44611-1", "AC", 4.0);
        cout << "Please enter 1 for showing CGPA: ";
        string s;
        cin >> s;
        cout << endl;
        Search(root, s);
        cout << "Reading tree in preorder : \n";
        PreOrder(root);
        cout<<"============================"<< endl;

    }
