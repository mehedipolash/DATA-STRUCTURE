#include<iostream>
#include<stack>
#include<queue>
using namespace std;

int priority(char op){
    if(op == '+' || op == '-')return 1;
    if(op == '*' || op == '/')return 2;
    if(op=='^')return 3;
    return 0;
}

int main(){
    stack <char> st;
    queue <char> infix,postfix;

    infix.push('(');
    //read infix expression
    cout<<"Enter Infix: ";
    char s,t;
    while(1){
        cin.get(s);
        if(s == ' ')continue;
        if(s == '\n')break;
        infix.push(s);
    }
    infix.push(')');

    //convert to postfix
    while(!infix.empty()){
        s = infix.front();
        infix.pop();
        if(s == '+' || s == '-' || s == '*' || s=='/'){
            //CODE
           //check the precedence of top element
           //if precedence is same or more pop else stop
           //push the current operator to stack
           while(!st.empty()&& priority(s)<=priority(st.top())){
                postfix.push(st.top());
                st.pop();
           }
           st.push(s);
        }
        else if(s == '('){
             //CODE
             st.push(s);
        }
        else if(s == ')'){
            //pop from stack until ( is found
            //and add the popped elements to postfix
            while(st.top()!='('){
                    postfix.push(st.top());
                    st.pop();
                  }
                  st.pop();
        }
        else{
            // append the current symbol to postfix
            postfix.push(s);
        }
    }

    //print postfix expression
    cout<< "\nPostfix: ";
    // Printing content of queue
    while (!postfix.empty()) {
        cout << ' ' << postfix.front()<<",";
        postfix.pop();
    }
    cout<<endl;

    return 0;
    main();
}
