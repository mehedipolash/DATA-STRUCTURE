#include<iostream>
using namespace std;
int top=0;
int stk[10];

void push(int v)
{
    {stk[top]=v;
    top++;}
}
void pop()
{
    top--;
}
void show()
{
    for(int i=top-1;i>=0;i--)
    {
        cout<<stk[i]<<endl;
    }
}
int main()
{
    cout<<"------------after push-----------------\n";
    push(7);
    push(4);
    show();
    cout<<"------------after pop-----------------\n";
    pop();
    pop();
    show();
}
