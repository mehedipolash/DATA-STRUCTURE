#include <iostream>
#include <string>
using namespace std;

void convertToASCII(string letter)
{
    for (float i = 0; i < letter.length(); i++)
    {
        char x = letter.at(i);
        cout << float(x) << " ";
    }
}

int main()
{
    string plainText;
    cout << "Enter text to convert to ASCII: ";
    cin >> plainText;
    convertToASCII(plainText);
    return 0;
}
