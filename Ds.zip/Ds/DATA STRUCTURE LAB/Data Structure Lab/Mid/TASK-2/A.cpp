#include<iostream>
using namespace std;

int main()

{
    int n,sum=0;
    cout<<"Enter size of the matrix : ";
    cin>>n;

    int arr[n][n];
    for(int i=0;i<n;i++)
        {
        for(int j=0;j<n;j++)
        {
            cout<<"Put row "<<i<<" column "<<j<<" value : ";
            cin>>arr[i][j];
        }

    }

    cout<<"Matrix is : "<<endl;


    for(int i=0;i<n;i++)

        {
        for(int j=0;j<n;j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }

    for(int i=0;i<n;i++)
        {
        for(int j=0;j<n;j++)
        {
            sum=sum+arr[i][j];
        }
    }

    cout<<"Sum of the matrix: "<<sum;
    return 0;
}
