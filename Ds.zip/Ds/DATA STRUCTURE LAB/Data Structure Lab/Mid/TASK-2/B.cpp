#include<iostream>
using namespace std;

int main()

{

    int a,b,c,d;
    cout<<"Enter the size of row of 1st matrix: ";
    cin>>a;

    cout<<"Enter the size of column of 1st matrix: ";
    cin>>b;

    int arr[a][b];
    for(int i=0;i<a;i++)

        {
        for(int j=0;j<b;j++)

        {
            cout<<"Enter 1st matrix row "<<i<<" column "<<j<<" value : ";
            cin>>arr[i][j];
        }

    }

   // int a1,b1;
    cout<<"Enter the size of row of 2nd matrix: ";
    cin>>c;

    cout<<"Enter the size of column of 2nd matrix: ";
    cin>>d;

    int arr1[a][b];
    for(int i=0;i<c;i++)

        {

        for(int j=0;j<d;j++)

        {
            cout<<"Enter 2nd matrix row "<<i<<" column "<<j<<" value : ";
            cin>>arr1[i][j];
        }

    }

    cout<<"1st matrix is : "<<endl;

    for(int i=0;i<a;i++)

        {

        for(int j=0;j<b;j++)

        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }

    cout<<"2nd matrix is : "<<endl;

    for(int i=0;i<c;i++)

        {

        for(int j=0;j<d;j++)

        {
            cout<<arr1[i][j]<<" ";
        }
        cout<<endl;
    }

    if([a][b]==[c][d])
    {
         int arr2[a][b];

    for(int i=0;i<a;i++)

    {
        for(int j=0;j<b;j++)

        {
            arr2[i][j]=arr[i][j]+arr1[i][j];
        }
    }

    cout<<"Sum of the matrix is : "<<endl;

    for(int i=0;i<a;i++)

        {

        for(int j=0;j<b;j++)

        {
            cout<<arr2[i][j]<<" ";
        }

        cout<<endl;
    }


    return 0;

    }


}
