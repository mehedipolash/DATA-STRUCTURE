#include<iostream>
#include<string.h>
using namespace std;

struct AppDate{
    int day;
    int month;
    int year;

    string getDate(){
        return to_string(day)+"/"+to_string(month)+"/"+to_string(year);
    }
    void showDate(){
        cout<<getDate()<<endl;
    }

};
struct AppTime{
    int hour;
    int minute;
    string getTime(){
        return to_string(hour)+":"+to_string(minute);
    }

    void showTime(){
        cout<<getTime()<<endl;
    }


} t;

struct Appointment{
    AppDate date;
    AppTime time;
    string location;
    void show(){
        cout<<"Location : "<<location<<endl;
        cout<<"Appointment Date: "<< date.getDate()<<endl;
        cout<<"Appointment Time: "<<time.getTime()<<endl;
    }
};


int main(){
    AppDate d = {13,2,2023};
    AppTime t = {5,10};

    Appointment apps[5];

    apps[0].date = d;
    apps[0].time = t;
    apps[0].location = "Kuratoli";
    //apps[0].show();

    apps[1].date = {13,2,2023};
    apps[1].time = {5,45};
    apps[1].location = "Kuratoli";
    //apps[1].show();

    for(int i=0;i<2;i++){
        if(apps[i].time.hour == 5 &&
           apps[i].time.minute <= 59 &&
           apps[i].time.minute >= 30){
            apps[i].show();
        }
    }


return 0;
}
