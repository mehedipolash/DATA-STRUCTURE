#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int x,y;
    cout<<"Enter row size"<<endl;
    cin>>x;
    cout<<"Enter coloumn size"<<endl;
    cin>>y;
    int matrix[x][y];

    for(int i=0;i<x;i++)
    {
        for(int j=0;j<y;j++)
        {
            cout<<"Enter the element for row "<<i<<" coloumn "<<j<<" :"<<endl;
            cin>>matrix[i][j];
        }
    }
     cout<<"Matrix is : "<<endl;

    for(int i=0;i<x;i++)
    {
        for(int j=0;j<y;j++)
        {
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }

    cout<<"******************************"<<endl;
    int transpose_matrix[y][x];

     for(int i=0;i<x;i++)
    {
        for(int j=0;j<y;j++)
        {
            transpose_matrix[j][i]=matrix[i][j];

        }
    }
    cout<<"Transpose matrix is : \n";

    for(int i=0;i<x;i++)
    {
        for(int j=0;j<y;j++)
        {
            cout<<transpose_matrix[i][j]<<" ";
        }
        cout<<endl;
    }


}
